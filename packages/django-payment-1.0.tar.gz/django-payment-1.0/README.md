# payment package

## Installation

- add the application in installed applications
- add the payment methods credentials in the .env file just like the following example

```python
#-----------------------accept------------------------
Accept_API_KEY="ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFh"
INTEGRATION_ID=26310
IFRAME_ID=43518
```

## how to use

- add one to one relationship between your order model and the package Payment Model
- create a Payment object then attach it to your order object
- you will find your iframe link in the payment object <3

## add new providers

- clone accept handler in providers folder and change the functionality to achieve your goals
- add your provider class to payment_providers dict in utils file
- add your provider to the conf file

## How to create new build

- change version in setup.cfg
- call make build in your terminal