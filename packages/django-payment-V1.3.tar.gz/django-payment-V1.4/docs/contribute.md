# Contribute

## [Add New Providers](./how-to-add-provider.md)

## create new build

1. change version in setup.cfg
2. call make build in your terminal
3. create a new tag in your current commit
4. make a new relase in gitlab


## Try the Package in project

At first, you will need to add the package directory to your python path.

open terminal in the project directory, and run:

```bash
export PYTHONPATH="..:$PYTHONPATH"
```

then you could enter the example path, run the migrations, create super user and run the server.

```bash
cd test_project
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

then you could try the package.
