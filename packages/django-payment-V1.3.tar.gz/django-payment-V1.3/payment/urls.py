from django.urls import path

from . import views

urlpatterns = [
    path(
        "opay-callback/",
        views.OPayView.as_view(),
        name="opay-callback",
    ),
]
