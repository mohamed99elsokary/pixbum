import requests
from decouple import config
from django.urls import reverse

OPAY_MERCHANT_ID = config("OPAY_MERCHANT_ID")
OPAY_PUBLIC_KEY = config("OPAY_PUBLIC_KEY")
OPAY_PRODUCTION_STAGE = config("OPAY_PRODUCTION_STAGE")
BACK_END_BASE_URL = config("BACK_END_BASE_URL")
CALLBACK_URL = BACK_END_BASE_URL + reverse("opay-callback")
# OPAY_SECRET_KEY = config("OPAY_SECRET_KEY")

OPAY_URL = "https://sandboxapi.opaycheckout.com/api/v1/international/cashier/create"

if OPAY_PRODUCTION_STAGE == "production":
    OPAY_URL = "https://api.opaycheckout.com/api/v1/international/cashier/create"


class OPayPaymentHandler:
    def __init__(self, payment: object) -> None:
        self.payment = payment

        response = self.create_request()
        if response.status_code == 200:
            response_obj = response.json().get("data", {})
            self.i_frame = response_obj.get("cashierUrl")
            self.order_id = response_obj.get("orderNo")
            self.token = None
        else:
            self.i_frame = None
            self.order_id = None
            self.token = None

    def create_request(self):
        body = {
            "country": "EG",
            "reference": f"{self.payment.slug}",
            "amount": {
                "total": self.payment.total * 100,
                "currency": self.payment.currency,
            },
            "callbackUrl": CALLBACK_URL,
            "expireAt": 300,
            "userInfo": {
                "userEmail": self.payment.email,
                "userId": self.payment.slug,
                "userMobile": self.payment.phone,
                "userName": f"{self.payment.first_name} {self.payment.last_name}",
            },
            "productList": [
                {
                    "productId": "productId",
                    "name": "name",
                    "description": "description",
                    "price": 100,
                    "quantity": 2,
                    "imageUrl": "https://imageUrl.com",
                }
            ],
            "payMethod": self.payment_method,
        }

        headers = {
            "MerchantId": OPAY_MERCHANT_ID,
            "Authorization": "Bearer %s" % OPAY_PUBLIC_KEY,
            "Content-Type": "application/json",
        }

        return requests.post(OPAY_URL, json=body, headers=headers)


class OPayCreditCardPaymentHandler(OPayPaymentHandler):
    payment_method = "BankCard"


class OPayMobileWalletPaymentHandler(OPayPaymentHandler):
    payment_method = "MWALLET"
