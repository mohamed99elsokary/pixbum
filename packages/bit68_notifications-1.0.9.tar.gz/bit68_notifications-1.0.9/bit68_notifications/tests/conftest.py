from unittest import mock

import firebase_admin
import pytest
from bit68_notifications.tests.factories import *  # noqa
from firebase_admin import credentials


@pytest.fixture(scope="session", autouse=True)
def my_thing_mock():
    with mock.patch.object(firebase_admin, "initialize_app") as _fixture:
        yield _fixture


@pytest.fixture(scope="session", autouse=True)
def my_thing_mock1():
    with mock.patch.object(credentials, "Certificate") as _fixture:
        yield _fixture


@pytest.fixture(autouse=True)
def media_storage(settings, tmpdir):
    settings.MEDIA_ROOT = tmpdir.strpath
