import json

import requests
from decouple import config

OPAY_MERCHANT_ID = config("OPAY_MERCHANT_ID")
OPAY_PUBLIC_KEY = config("OPAY_PUBLIC_KEY")
OPAY_PRODUCTION_STAGE = config("OPAY_PRODUCTION_STAGE")
CALLBACK_URL = config("CALLBACK_URL")
RETURN_URL = config("RETURN_URL")
# OPAY_SECRET_KEY = config("OPAY_SECRET_KEY")

OPAY_URL = "https://sandboxapi.opaycheckout.com/api/v1/international/cashier/create"

if OPAY_PRODUCTION_STAGE == "production":
    OPAY_URL = "https://api.opaycheckout.com/api/v1/international/cashier/create"


class OPayPaymentHandler:
    def __init__(self, payment: object) -> None:
        self.payment = payment

        response = self.create_request()

        if response.status_code == 200:
            response_obj = response.json().get("data", {})
            self.i_frame = response_obj.get("cashierUrl")
            self.order_id = response_obj.get("orderNo")
            self.auth_token = None
        else:
            self.i_frame = None
            self.order_id = None
            self.auth_token = None

    def create_request(self):
        body = json.dumps(
            {
                "country": "EG",
                "reference": self.payment.slug,
                "amount": {
                    "total": int(self.payment.total * 100),
                    "currency": self.payment.currency,
                },
                "returnUrl": RETURN_URL,
                "callbackUrl": CALLBACK_URL,
                "expireAt": 300,
                "userInfo": {
                    "userEmail": self.payment.email,
                    "userId": self.payment.slug,
                    "userMobile": self.payment.phone,
                    "userName": f"{self.payment.first_name} {self.payment.last_name}",
                },
                "productList": [
                    {
                        "productId": "productId",
                        "name": "name",
                        "description": "description",
                        "price": 100,
                        "quantity": 2,
                        "imageUrl": "https://imageUrl.com",
                    }
                ],
                "payMethod": self.payment_method,
            }
        )

        headers = {
            "MerchantId": OPAY_MERCHANT_ID,
            "Authorization": f"Bearer {OPAY_PUBLIC_KEY}",
            "Content-Type": "application/json",
        }

        return requests.request(
            "POST",
            OPAY_URL,
            headers=headers,
            data=body,
        )


class OPayCreditCardPaymentHandler(OPayPaymentHandler):
    payment_method = "BankCard"


class OPayMobileWalletPaymentHandler(OPayPaymentHandler):
    payment_method = "MWALLET"
