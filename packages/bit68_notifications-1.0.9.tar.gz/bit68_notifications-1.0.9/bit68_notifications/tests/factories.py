from bit68_notifications.models import BulkNotification, ExpoDevice, FirebaseDevice
from factory import Faker
from factory.django import DjangoModelFactory
from pytest_factoryboy import register


@register
class ExpoDeviceFactory(DjangoModelFactory):
    class Meta:
        model = ExpoDevice

    registration_id = Faker("slug")


@register
class FirebaseDeviceFactory(DjangoModelFactory):
    class Meta:
        model = FirebaseDevice

    registration_id = Faker("slug")


@register
class BulkNotificationFactory(DjangoModelFactory):
    class Meta:
        model = BulkNotification

    title = Faker("text", max_nb_chars=60)
    body = Faker("text")
