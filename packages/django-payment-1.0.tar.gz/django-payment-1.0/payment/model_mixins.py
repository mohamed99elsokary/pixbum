from django_lifecycle import BEFORE_CREATE, LifecycleModelMixin, hook

from .utils import payment_providers


class PaymentMixin(LifecycleModelMixin):
    def get_payment_provider(self):
        return payment_providers[self.payment_type](
            price=self.total, currency=self.currency
        )

    @hook(BEFORE_CREATE)
    def after_create(self):
        payment_data = self.get_payment_provider().initiate()
        self.payment_url = payment_data["i_frame"]
        self.provider_order_id = payment_data["order_id"]
        self.provider_token = payment_data["token"]
