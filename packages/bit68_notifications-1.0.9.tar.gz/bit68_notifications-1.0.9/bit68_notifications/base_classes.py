class BaseNotificationHandler:
    log = ""

    def send_message(self, tokens, title, body, data=None, **kwargs):
        raise NotImplementedError

    def _log(self, log):
        delimeter = "\n"
        self.log += log + delimeter

    def send_to_topic(self):
        pass
