from django.db import models

# Create your models here.
from payment.models import Payment

from .model_mixins import OrderMixin


class Order(OrderMixin, models.Model):
    payment = models.OneToOneField(
        Payment,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        default=None,
    )
    payment_url = models.CharField(max_length=2000, null=True, blank=True, default=None)
    total_price = models.IntegerField(default=0)
