.. highlight:: shell

============
Contributing
============


Get Started!
------------

Ready to contribute? Here's how to set up `bit68_notifications` for local development.

1. clone the `bit68_notifications` repo from gitlap.

2. go to your project

3. Install your local copy into a virtualenv. Assuming you have virtualenvwrapper installed, this is how you set up your fork for local development::

    $ virtualenv  env
    $ source env/bin/activate
    $ cd bit68_notifications/
    $ python setup.py develop

4. Create a branch for local development::

    $ git checkout -b name-of-your-bugfix-or-feature

   Now you can make your changes locally.

5. When you're done making changes, check that your changes pass flake8 and the
   tests, including testing other Python versions with tox::

    $ flake8 bit68_notifications tests
    $ python setup.py test # or `pytest`
    $ tox

   To get flake8 and tox, just pip install them into your virtualenv.

6. Commit your changes and push your branch to GitHub::

    $ git add .
    $ git commit -m "Your detailed description of your changes."
    $ git push origin name-of-your-bugfix-or-feature

7. Submit a Merge request through the GitHub website.

Merge Request Guidelines
-----------------------

Before you submit a merge request, check that it meets these guidelines:

1. The merge request should include tests.
2. If the merge request adds functionality, the docs should be updated. Put
   your new functionality into a function with a docstring, and add the
   feature to the list in README.rst.
3. The merge request should work for Python 3.5, 3.6, 3.7 and 3.8, and for PyPy.

Tips
----

To run a subset of tests::

$ pytest tests.test_bit68_notifications
