# payment package

## Installation

- add the application in installed applications
  
    ```python
    THIRD_PARTY_APPS = [
        ...
        "payment",
        ...
    ]
    ```

- add the payment methods credentials in the .env file just like the following example

    ```python
    #-----------------------accept------------------------
    Accept_API_KEY="ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFh"
    INTEGRATION_ID=26310
    IFRAME_ID=43518
    ```

## how to use

- add one to one relationship between your order model and the package Payment Model like this example

    ```python
    from payment.models import Payment
    from .model_mixins import OrderDetailsMixin, OrderMixin
    #import your user model 

    
    class Order(OrderMixin,models.Model):
    # relations
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    payment = models.OneToOneField(
        Payment,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        default=None,
    )
    
    payment_url = models.CharField(max_length=2000,null=True, blank=True, default=None)
    # fields
    total_price = models.IntegerField(default=0)
    ```

- create a Payment object using before create hook on oder model

    ```python
    from payment.models import Payment
    from django_lifecycle import (
    BEFORE_CREATE,
    LifecycleModelMixin,
    hook,
    )

    class OrderMixin(LifecycleModelMixin):
    @hook(BEFORE_CREATE)
    def create_payment(self):
        #choose the payment type depends on which payment gateway that u need to use
        self.payment = Payment.objects.create(payment_type="ACCEPT_CREDIT_CARD",currency="EGP",total=self.total_price)
        self.payment_url = self.payment.payment_url
    ```

## add new providers

- clone accept handler in providers folder and change the functionality to achieve your goals
- add your provider class to payment_providers dict in utils file
- add your provider to the conf file

## How to create new build

- change version in setup.cfg
- call make build in your terminal