from django.contrib import admin
from unfold.admin import ModelAdmin

from . import models


@admin.register(models.Payment)
class PaymentAdmin(ModelAdmin):
    """Admin View for Payment"""
