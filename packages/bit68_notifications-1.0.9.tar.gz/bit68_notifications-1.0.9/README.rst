.. highlight:: shell

.. https://pythonhosted.org/an_example_pypi_project/sphinx.html#links

===================
bit68_notifications
===================






Create notifications and push notifications and handle it from the admin panel



Features
--------

* register and send push notifications (Currently support Expo only)


Build the docs
---------------

1. intialize virtual environment
2. activate environment
3. install requirements from `requirements_dev.txt`
4. build docs
    .. code-block:: console

        $ make html
5. you can now open the `docs/_build/html/index.html` and check the documentation in browser
