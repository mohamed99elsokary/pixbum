from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import redirect
from django.http import HttpResponse

from . import models


class AcceptView(APIView):
    def after_payment_success(self, provider_order_id):
        payment = models.Payment.objects.get(provider_order_id=provider_order_id)
        payment.paid = True
        payment.save()
        return redirect("payment_success")

    def payment_handler(self, success, provider_order_id):
        if success == "true":
            return self.after_payment_success(provider_order_id)
        else:
            return redirect("payment_failed")

    def get(self, request):
        success = request.GET["success"]
        provider_order_id = request.GET["order"]
        return self.payment_handler(success, provider_order_id)

    def post(self, request):
        provider_order_id = request.data["obj"]["order"]["id"]
        success = request.data["obj"]["success"]
        return self.payment_handler(success, provider_order_id)


class OPayView(APIView):
    def after_payment_susses(self, provider_order_id, token):
        payment = models.Payment.objects.get(provider_order_id=provider_order_id)
        payment.provider_token = token
        payment.paid = True
        payment.save()
        return redirect("payment_success")

    def payment_handler(self, status, provider_order_id, token):
        if status == "SUCCESS":
            return self.after_payment_susses(provider_order_id, token)
        else:
            return redirect("payment_failed")

    def get(self, request):
        success = request.GET["status"]
        provider_order_id = request.GET["transactionId"]
        token = request.GET["token"]
        return self.payment_handler(success, provider_order_id, token)

    def post(self, request):
        provider_order_id = request.data["payload"]["transactionId"]
        token = request.data["payload"]["token"]
        status = request.data["payload"]["status"]
        return self.payment_handler(status, provider_order_id, token)


def payment_success(request):
    return HttpResponse("payment success")


def payment_failed(request):
    return HttpResponse("payment failed")
