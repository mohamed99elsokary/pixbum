.. highlight:: shell

============
Installation
============


Stable release
--------------

To install bit68_notifications, get the latest release from gitlap package registry 
https://gitlab.com/bit68/packages/bit68_notifications/-/packages/2315013

then run the following command to install the package:

.. code-block:: console

    $ pip install bit68_notifications-<version>.tar.gz

This is the preferred method to install bit68_notifications.


From sources
------------

The sources for bit68_notifications can be downloaded from the `Github repo`_.

You can either clone the public repository:

.. code-block:: console

    $ git clone git@gitlab.com:bit68/packages/bit68_notifications.git

Once you have a copy of the source, you can install it with:

.. code-block:: console

    $ python setup.py install


.. _Github repo: https://github.com/mtaweela/bit68_notifications
.. _tarball: https://github.com/mtaweela/bit68_notifications/tarball/master
