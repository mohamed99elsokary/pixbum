from django.conf import settings


class NotificationSettings:
    """
    This is a simple class to take the place of the global settings object.

    An instance will contain all of our settings as attributes, with default
    values if they are not specified by the configuration.
    """

    defaults = {
        "PUSH_NOTIFICATION_USER_MODEL": settings.AUTH_USER_MODEL,
        "PUSH_NOTIFICATION_UNIQUE_REG_ID": False,
        "PUSH_NOTIFICATION_DEVICE_TYPES": [],
        "IS_TESTING_ENVIRONMENT": False,
        "FIREBASE_PROFILES": {
            "default": {
                "PUSH_NOTIFICATION_FIREBASE_KEY": None,
                "DEFAULT_DATA": {},
            }
        },
    }

    def __getattr__(self, name):
        if name in self.defaults:
            return getattr(settings, name, self.defaults[name])
        else:
            return getattr(settings, name)


notification_settings = NotificationSettings()
