from django import forms
from django.contrib import admin

from .conf import EXPO_NOTIFICATION, FIREBASE_NOTIFICATION
from .models import BulkNotification, ExpoDevice, FirebaseDevice
from .settings import notification_settings as SETTINGS


class DeviceAdmin(admin.ModelAdmin):
    list_display = (
        "__str__",
        "device_id",
        "user",
        "active",
        "date_created",
        "registration_id",
    )
    list_filter = ("active",)
    raw_id_fields = ("user",)


if EXPO_NOTIFICATION in SETTINGS.PUSH_NOTIFICATION_DEVICE_TYPES:

    @admin.register(ExpoDevice)
    class ExpoDeviceAdmin(DeviceAdmin):
        search_fields = ("device_id", "registration_id")


if FIREBASE_NOTIFICATION in SETTINGS.PUSH_NOTIFICATION_DEVICE_TYPES:

    class FirebaseDeviceForm(forms.ModelForm):
        APP_CHOICES = ((k, k) for k, v in SETTINGS.FIREBASE_PROFILES.items())

        app_name = forms.ChoiceField(choices=APP_CHOICES)

    @admin.register(FirebaseDevice)
    class FirebaseDeviceAdmin(DeviceAdmin):
        search_fields = ("device_id", "registration_id")
        form = FirebaseDeviceForm


class BulkNotificationForm(forms.ModelForm):
    APP_CHOICES = (
        ("", "----------"),
        *[(k, k) for k, v in SETTINGS.FIREBASE_PROFILES.items()],
    )

    firebase_app_name = forms.ChoiceField(choices=APP_CHOICES)


@admin.register(BulkNotification)
class BulkNotificationAdmin(admin.ModelAdmin):
    list_display = (
        "__str__",
        "id",
        "title",
        "body",
        "date_created",
        "type",
        "is_successful",
        "response_log",
    )
    readonly_fields = ("is_successful", "response_log")
    list_filter = ("is_successful",)
    form = BulkNotificationForm
