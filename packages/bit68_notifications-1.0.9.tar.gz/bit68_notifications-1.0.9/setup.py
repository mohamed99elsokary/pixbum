#!/usr/bin/env python

"""The setup script."""

from setuptools import find_packages, setup

import bit68_notifications

with open("README.rst") as readme_file:
    readme = readme_file.read()

with open("HISTORY.rst") as history_file:
    history = history_file.read()

requirements = [
    "exponent-server-sdk",
    "firebase-admin",
]

setup_requirements = [
    "pytest-runner",
]

test_requirements = [
    "pytest>=3",
]

setup(
    author="Mohamed Taweela",
    author_email="mohamed.taweela@bit68.com",
    python_requires=">=3.5",
    classifiers=[
        "Development Status :: 2 - Pre-Alpha",
        "Intended Audience :: Developers",
        "Natural Language :: English",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.5",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
    ],
    description="Create notifications and push notifications and handle it from the admin panel",
    install_requires=requirements,
    long_description=readme + "\n\n" + history,
    include_package_data=True,
    keywords="bit68_notifications",
    name="bit68_notifications",
    packages=find_packages(
        include=[
            "bit68_notifications",
            "bit68_notifications.*",
        ]
    ),
    setup_requires=setup_requirements,
    test_suite="tests",
    tests_require=test_requirements,
    url="https://github.com/mtaweela/bit68_notifications",
    version="1.0.9",
    zip_safe=False,
)
