from unittest.mock import patch

import pytest
from bit68_notifications.base_classes import BaseNotificationHandler
from bit68_notifications.conf import EXPO_NOTIFICATION, FIREBASE_NOTIFICATION
from bit68_notifications.models import BulkNotification, ExpoDevice, FirebaseDevice

pytestmark = pytest.mark.django_db
lazy_fixture = pytest.lazy_fixture


class TestExpoDeviceManager:
    def test_queryset(self, expo_device):
        # just assert query is working
        assert ExpoDevice.objects.all().exists()


class TestExpoDeviceQuerySet:
    @patch("bit68_notifications.expo.ExpoSendHandler.send_message")
    def test_send_message(self, mock_func, expo_device_factory):
        active_devices = expo_device_factory.create_batch(4)
        expo_device_factory.create_batch(1, active=False)

        # input
        title = "title"
        body = "body"
        kwargs = {}
        # test call with empty query
        assert not ExpoDevice.objects.none().send_message(title, body, **kwargs)
        # test call with query that has data
        assert ExpoDevice.objects.all().send_message(title, body, **kwargs)
        mock_func.assert_called_with(
            [d.registration_id for d in active_devices],
            title,
            body,
            kwargs.pop("extra", {}),
            **kwargs,
        )


class TestExpoDevice:
    @patch("bit68_notifications.expo.ExpoSendHandler.send_message")
    def test_send_message(self, mock_func, expo_device):
        title = "title"
        body = "body"
        kwargs = {}
        expo_device.send_message(title, body, **kwargs)
        mock_func.assert_called_with(
            [expo_device.registration_id],
            title,
            body,
            kwargs.pop("extra", {}),
            **kwargs,
        )


class TestFirebaseManager:
    def test_queryset(self, firebase_device):
        # just assert query is working
        assert FirebaseDevice.objects.all().exists()


class TestFirebaseQuerySet:
    @patch("bit68_notifications.firebase.FirebaseHandler.send_message_to_many")
    @patch("firebase_admin.get_app")
    def test_send_message(
        self, firebase_get_app_mock, mock_func, firebase_device_factory
    ):
        active_devices = firebase_device_factory.create_batch(4)
        firebase_device_factory.create_batch(1, active=False)

        # input
        title = "title"
        body = "body"
        kwargs = {}
        # test call with empty query
        assert not FirebaseDevice.objects.none().send_message(title, body, **kwargs)
        # test call with query that has data
        assert FirebaseDevice.objects.all().send_message(title, body, **kwargs)
        mock_func.assert_called_with(
            [d.registration_id for d in active_devices],
            title,
            body,
            kwargs.pop("extra", {}),
            **kwargs,
        )


class TestFirebaseDevice:
    @patch("bit68_notifications.firebase.FirebaseHandler.send_message")
    @patch("firebase_admin.get_app")
    def test_send_message(self, firebase_get_app_mock, mock_func, firebase_device):
        title = "title"
        body = "body"
        kwargs = {}
        firebase_device.send_message(title, body, **kwargs)
        mock_func.assert_called_with(
            token=firebase_device.registration_id,
            title=title,
            body=body,
            extra=kwargs.pop("extra", {}),
            **kwargs,
        )


class ExpoSendHandlerMock(BaseNotificationHandler):
    failed_tokens = []
    is_failed_request = False


class FirebaseSendHandlerMock(BaseNotificationHandler):
    pass


class TestBulkNotification:
    @patch("bit68_notifications.models.BulkNotification.send")
    def test_save(self, mock_fun):
        bulk_notif = BulkNotification.objects.create()
        mock_fun.assert_called_once()
        bulk_notif.save()
        mock_fun.assert_called_once()

    @patch(
        "bit68_notifications.models.ExpoDeviceQuerySet.send_message",
        return_value=ExpoSendHandlerMock(),
    )
    @patch(
        "bit68_notifications.models.FirebaseQuerySet.send_message",
        return_value=FirebaseSendHandlerMock(),
    )
    def test_send(
        self,
        firebase_device_send_mock,
        expo_device_send_mock,
        bulk_notification_factory,
    ):
        # expo
        bulk_notification_factory(type=EXPO_NOTIFICATION)
        expo_device_send_mock.assert_called_once()
        # firebase
        bulk_notification_factory(type=FIREBASE_NOTIFICATION)
        firebase_device_send_mock.assert_called_once()
