# Needs ASAP

* [X] integrate Accept payment
* [X] add Accept call back url
* [X] integrate Opay payment
* [ ] create an example project
* [ ] implment all payment gateways in the example project
* [X] integrate Opay Wallet
* [X] integrate Accept Wallet
