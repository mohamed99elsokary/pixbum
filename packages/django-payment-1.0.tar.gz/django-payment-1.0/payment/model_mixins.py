from django_lifecycle import LifecycleModelMixin, hook, BEFORE_CREATE, AFTER_UPDATE
from django.conf import settings
from .utils import payment_providers
from django.conf import settings


class PaymentMixin(LifecycleModelMixin):
    def get_payment_provider(self):
        return payment_providers[self.payment_type](
            price=self.total, currency=self.currency
        )

    @hook(BEFORE_CREATE)
    def after_create(self):
        payment_data = self.get_payment_provider().initiate()
        self.payment_url = payment_data["i_frame"]
        self.provider_order_id = payment_data["order_id"]
        self.provider_token = payment_data["token"]

    @hook(AFTER_UPDATE, when="paid", is_now=True)
    def after_payment(self):
        if settings.AFTER_PAYMENT_SUCCESS:
            settings.AFTER_PAYMENT_SUCCESS(self)
