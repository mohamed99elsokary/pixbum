# Installation

1. download the build that you want from dist directory and put in a packages dir in your project
2. add the package in the requirements file

   ```python
   ./packages/django-payment-1.0.tar.g
   ```
3. add the application in installed applications

   ```python
   THIRD_PARTY_APPS = [
       ...
       "payment",
       ...
   ]
   ```
4. add the payment methods credentials in the .env file just like the following example

   ```python
   #_______________________accept_______________________
   Accept_API_KEY="xxxx"
   INTEGRATION_ID=xxxx
   IFRAME_ID=xxxx
   ```

## [Usage](./how-to-use.md)
