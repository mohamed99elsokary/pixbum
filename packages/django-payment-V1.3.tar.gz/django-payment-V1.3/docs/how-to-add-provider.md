# How To Add New Payment Gateway

1. Create {provider_name}.py in providers folder
2. add provider credentials in {provider_name}.py

   ```python
   from decouple import config
   Provider_MERCHANT_ID = config("Provider_MERCHANT_ID")
   Provider_PUBLIC_KEY = config("Provider_PUBLIC_KEY")
   BACK_END_BASE_URL = config("BACK_END_BASE_URL")
   PROVIDER_ORDER_REQUEST = "https://acd.com"
   CALL_BACK_URL = f"{BACK_END_BASE_URL}{reverse("url-callback")}"
   ```

3. Add the provider handler class

   ```python
   import requests
   from decouple import config
   from django.urls import reverse

   class {ProviderName}Handler:
       def __init__(self, payment: object) -> None:
           
           self.payment = payment
           payment_request = self.create_request()

           if payment_request.status_code == 200:
               payment_request_obj = payment_request.json().get("data", {})
               self.i_frame = payment_request_obj.get("payment_url")
               self.order_id = payment_request_obj.get("orderNo")
               self.token = None
           
            else:
                self.i_frame = None
                self.order_id = None
                self.token = None

       def create_request(self):

           body = {
               "country": "EG",
               "reference": f"{self.payment.slug}",
               "amount": {
                   "total": self.payment.total * 100,
                   "currency": self.payment.currency,
               },
               "callbackUrl": CALL_BACK_URL,
               "expireAt": 300,
               "userInfo": {
                   "userEmail": self.payment.email,
                   "userId": self.payment.slug,
                   "userMobile": self.payment.phone,
                   "userName": f"{self.payment.first_name} {self.payment.last_name}",
               },
               "productList": [
                   {
                       "productId": "productId",
                       "name": "name",
                       "description": "description",
                       "price": 100,
                       "quantity": 2,
                       "imageUrl": "https://imageUrl.com",
                   }
               ],
               "payMethod": "BANK"",
           }

           headers = {
               "MerchantId":Provider_MERCHANT_ID,
               "Authorization": f"Bearer {Provider_PUBLIC_KEY}",
               "Content-Type": "application/json",
           }

           return requests.post(PROVIDER_ORDER_REQUEST, json=body, headers=headers)
   ```

4. Add your call back view

   ```python
   class {ProviderName}View(APIView):
       def after_payment_susses(self, provider_order_id, token):
           payment = models.Payment.objects.get(provider_order_id=provider_order_id)
           payment.provider_token = token
           payment.paid = True
           payment.save()
           return Response({"details": "Your Subscription added successfully"}, status=200)

       def payment_handler(self, status, provider_order_id, token):
           if status == "SUCCESS":
               return self.after_payment_susses(provider_order_id, token)
           else:
               return Response(
                   {"details": "Failed Transaction please try again"}, status=400
               )

       def get(self, request):
           success = request.GET["status_key"]
           provider_order_id = request.GET["order_id_key"]
           return self.payment_handler(success, provider_order_id)

       def post(self, request):
           provider_order_id = request.data["order_id_key"]
           status = request.data["status_key"]
           return self.payment_handler(status, provider_order_id)
   ```

5. Add your call-back to urls.py

   ```python
   from django.urls import path
   from . import views

   urlpatterns = [
       ...
       path("url-callback/",views.{ProviderName}View.as_view(),name="url-callback",)
       ...
   ]
   ```

6. Add the {ProviderName}Handler to the utils.py

```python
from .providers.{file_name} import {ProviderName}Handler

payment_providers = {
    ...
    "{ProviderName}": {ProviderName}Handler
    ...
}

```
