import json

from exponent_server_sdk import (
    DeviceNotRegisteredError,
    MessageRateExceededError,
    MessageTooBigError,
    PushClient,
    PushMessage,
    PushServerError,
    PushTicketError,
)
from requests.exceptions import ConnectionError, HTTPError

from .base_classes import BaseNotificationHandler


class ExpoSendHandler(BaseNotificationHandler):
    failed_tokens = []
    is_failed_request = False
    # is_all_failed = False

    def send_message(self, tokens, title, body, data=None, **kwargs):
        """send expo push notification

        Args:
            tokens (array of strings): expo tokens
            title (text): message title
            body (text): notification body
            data (dictionary, optional): notification additional data. Defaults to None.

        Returns:
            Tuple of two, is_success, error type
        """
        messages = [
            PushMessage(to=to, title=title, body=body, data=data, **kwargs) for to in tokens
        ]

        try:
            response = PushClient().publish_multiple(messages)
        except PushServerError as e:
            self.is_failed_request = True
            self._log("PushServerError")
            self._log(e.message)
            self._log(json.dumps(e.response_data))
        except (ConnectionError, HTTPError):
            self.is_failed_request = True
            self._log("ConnectionError")
        except ValueError as exc:
            self.is_failed_request = True
            self._log(str(exc))
        else:
            if type(response) == list:
                for r in response:
                    self.validate_response(r)
            else:
                self.validate_response(response)

    def validate_response(self, response):
        error_message = ""
        try:
            response.validate_response()
        except DeviceNotRegisteredError as exc:
            error_message = "DeviceNotRegisteredError" + " " + exc.message
        except MessageTooBigError as exc:
            error_message = "MessageTooBigError" + " " + exc.message
        except MessageRateExceededError as exc:
            error_message = "MessageRateExceededError" + " " + exc.message
        except PushTicketError as exc:
            error_message = "PushTicketError" + " " + exc.message
        finally:
            if error_message:
                self.is_failed_request = True
                token_error = "Token: %s, Reason: %s" % (
                    response.push_message.to,
                    error_message,
                )
                self.failed_tokens.append(token_error)
                self._log(error_message)
