from rest_framework import viewsets

from .models import Order
from .serializers import OrderSerializer


class TryAcceptOrderViewSet(viewsets.ModelViewSet):
    serializer_class = OrderSerializer
    queryset = Order.objects.all()

    def perform_create(self, serializer):
        order = serializer.save(total_price=100)
        print(order)
