from django.apps import AppConfig
import django

if django.VERSION >= (3, 2):
    from django.utils.translation import gettext_lazy as _
else:
    from django.utils.translation import ugettext_lazy as _


class PaymentConfig(AppConfig):
    name = "payment"
    verbose_name = _("Payment")
