import uuid

from .providers.accept import AcceptPaymentHandler


def get_unique_string():
    return uuid.uuid4().hex


payment_providers = {
    "ACCEPT_CREDIT_CARD": AcceptPaymentHandler,
}
