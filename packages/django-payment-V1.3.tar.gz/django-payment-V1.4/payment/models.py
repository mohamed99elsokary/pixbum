import django
from django.db import models
from django.utils import timezone

if django.VERSION >= (3, 2):
    from django.utils.translation import gettext_lazy as _
else:
    from django.utils.translation import ugettext_lazy as _

from .conf import CURRENCY_OPTION, PAYMENT_TYPES
from .model_mixins import PaymentMixin
from .utils import get_unique_string


class Payment(PaymentMixin, models.Model):
    # payment data
    slug = models.CharField(max_length=50, unique=True, default=get_unique_string)
    payment_type = models.CharField(
        _("Payment Type"), max_length=50, choices=PAYMENT_TYPES
    )

    # user data
    title = models.CharField(max_length=254)
    first_name = models.CharField(max_length=254)
    last_name = models.CharField(max_length=254)
    phone = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(max_length=254)
    wallet_mobile_number = models.CharField(max_length=255, null=True, blank=True)
    # order data
    currency = models.CharField(max_length=12, choices=CURRENCY_OPTION)
    total = models.FloatField(default=0)
    paid = models.BooleanField(default=False)
    log = models.TextField(_("Log"), null=True, blank=True)
    date_issued = models.DateTimeField(default=timezone.now)
    date_of_payment = models.DateTimeField(blank=True, null=True)
    # provider data
    payment_url = models.URLField(max_length=2000, null=True, blank=True, default=None)
    provider_order_id = models.CharField(
        max_length=2000, null=True, blank=True, default=None
    )
    provider_token = models.CharField(
        max_length=2000, null=True, blank=True, default=None
    )

    def __str__(self):
        return f"ID: {self.id}, title: {self.title}"
