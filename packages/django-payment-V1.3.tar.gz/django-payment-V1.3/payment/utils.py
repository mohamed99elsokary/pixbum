import uuid

from .providers.accept import (
    AcceptCreditCardPaymentHandler,
    AcceptMobileWalletPaymentHandler,
)
from .providers.opay import OPayCreditCardPaymentHandler, OPayMobileWalletPaymentHandler


def get_unique_string():
    return uuid.uuid4().hex


payment_providers = {
    "ACCEPT_CREDIT_CARD": AcceptCreditCardPaymentHandler,
    "ACCEPT_MOBILE_WALLET": AcceptMobileWalletPaymentHandler,
    "OPAY_CREDIT_CARD": OPayCreditCardPaymentHandler,
    "OPAY_MOBILE_WALLET": OPayMobileWalletPaymentHandler,
}
