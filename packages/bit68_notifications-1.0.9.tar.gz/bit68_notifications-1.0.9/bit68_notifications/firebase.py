import json

import firebase_admin
from firebase_admin import credentials, messaging

from .base_classes import BaseNotificationHandler
from .settings import notification_settings as SETTINGS

APPS = {}
DRY_RUN = SETTINGS.IS_TESTING_ENVIRONMENT

# Initialize firebase_admin
if not len(firebase_admin._apps):
    FIREBASE_PROFILES = SETTINGS.FIREBASE_PROFILES

    for app_name, v in FIREBASE_PROFILES.items():
        cred = credentials.Certificate(json.loads(v["PUSH_NOTIFICATION_FIREBASE_KEY"]))
        APPS[app_name] = firebase_admin.initialize_app(cred, name=app_name)


class FirebaseHandler(BaseNotificationHandler):
    # see https://firebase.google.com/docs/cloud-messaging/send-message#python_3
    app = None

    def __init__(self, app_name="default"):
        self.app = firebase_admin.get_app(app_name)
        self.app_name = app_name

    def send_message(self, token, title, body, data=None, **kwargs):
        message = messaging.Message(
            notification=messaging.Notification(title, body),
            data=self.get_data(data, title, body),
            token=token,
        )

        # Response is a message ID string.
        response = messaging.send(message, dry_run=DRY_RUN, app=self.app)
        self._log(response)
        return response

    def send_message_to_many(self, tokens_arr, title, body, data, **kwargs):
        all_responses = []
        for chunk in self.chunks(tokens_arr):
            message = messaging.MulticastMessage(
                notification=messaging.Notification(title, body),
                data=self.get_data(data, title, body),
                tokens=chunk,
            )
            response = messaging.send_multicast(message, dry_run=DRY_RUN, app=self.app)
            responses = response.responses
            exceptions = [r.exception for r in responses]
            message_ids = [r.message_id for r in responses]
            self._log(str(exceptions))
            self._log(str(message_ids))
            all_responses.append(responses)
        return all_responses

    def chunks(self, tokens_arr):
        split_size = 500
        tokens_count = len(tokens_arr)

        for start in range(0, tokens_count, split_size):
            end = start + split_size
            arr_chunk = tokens_arr[start:end]

            yield arr_chunk

    def send_many_messages_different_users(self, message_arr):
        """send differnet messages to differnet users but send them in bulk

        Args:
            message_arr (array): should be something like:

            [
                {"title": "Hello", "body": "Hello Sir", "data": {}, "token": "device_token"},
                {"title": "Hello", "body": "Hello Sir", "data": {}, "token": "device_token"},
                {"title": "Hello", "body": "Hello Sir", "data": {}, "token": "device_token"},
            ]
        """
        # TODO not tested
        messages = [
            messaging.Message(
                notification=messaging.Notification(
                    message.get("title"), message.get("body")
                ),
                data=self.get_data(
                    message.get("data"), message.get("title"), message.get("body")
                ),
                token=message.get("token"),
            )
            for message in message_arr
        ]
        response = messaging.send_all(messages, dry_run=DRY_RUN, app=self.app)
        self._log(response)
        return response

    def send_to_topic(self, topic, title, body, data=None, **kwargs):
        message = messaging.Message(
            notification=messaging.Notification(title, body),
            data=self.get_data(data, title, body),
            topic=topic,
        )

        # Response is a message ID string.
        response = messaging.send(message, dry_run=DRY_RUN, app=self.app)
        self._log(response)
        return response

    def get_data(self, data, title=None, body=None):
        new_data = {}
        new_data.update(
            SETTINGS.FIREBASE_PROFILES.get(self.app_name).get("DEFAULT_DATA", {})
        )
        new_data.update({"title": title, "message": body})
        new_data.update(data)
        return new_data
