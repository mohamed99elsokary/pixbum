from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import TryAcceptOrderViewSet

router = DefaultRouter()
router.register("try-accept-orders", TryAcceptOrderViewSet)

urlpatterns = [
    path("", include(router.urls)),
]
