import json

import requests
from decouple import config

AUTH_URL = "https://accept.paymob.com/api/auth/tokens"
ORDER_URL = "https://accept.paymob.com/api/ecommerce/orders"
I_FRAME_CREATOR_URL = "https://accept.paymob.com/api/acceptance/payment_keys"
I_FRAME_URL = "https://accept.paymob.com/api/acceptance/iframes/"

Accept_API_KEY = config("Accept_API_KEY")
INTEGRATION_ID = config("INTEGRATION_ID")
IFRAME_ID = config("IFRAME_ID")


class AcceptPaymentHandler:
    def __init__(self, price: int, currency: str) -> None:
        self.price = price * 100
        self.currency = currency

    def initiate(self):
        self.token = self.get_token()
        self.order_id = self.create_order()
        self.i_frame = self.get_iframe()
        return {
            "token": self.token,
            "order_id": self.order_id,
            "i_frame": self.i_frame,
        }

    def get_token(self):
        response = requests.request(
            "POST",
            AUTH_URL,
            headers={"Content-Type": "application/json"},
            data=json.dumps({"api_key": Accept_API_KEY}),
        )
        response = json.loads(response.text)
        return response["token"]

    def create_order(self):
        payload = json.dumps(
            {
                "auth_token": self.token,
                "delivery_needed": False,
                "amount_cents": self.price,
                "currency": "EGP",
                "items": [],
            }
        )

        response = requests.request(
            "POST",
            ORDER_URL,
            headers={"Content-Type": "application/json"},
            data=payload,
        )
        response = json.loads(response.text)
        return response["id"]

    def get_iframe(self):
        payload = json.dumps(
            {
                "auth_token": self.token,
                "amount_cents": self.price,
                "expiration": 3600,
                "order_id": self.order_id,
                "billing_data": {
                    "apartment": "803",
                    "email": "claudette09@exa.com",
                    "floor": "42",
                    "first_name": "Clifford",
                    "street": "Ethan Land",
                    "building": "8028",
                    "phone_number": "+86(8)9135210487",
                    "shipping_method": "PKG",
                    "postal_code": "01898",
                    "city": "Jaskolskiburgh",
                    "country": "CR",
                    "last_name": "Nicolas",
                    "state": "Utah",
                },
                "currency": self.currency,
                "integration_id": INTEGRATION_ID,
            }
        )
        headers = {"Content-Type": "application/json"}
        response = requests.request(
            "POST", I_FRAME_CREATOR_URL, headers=headers, data=payload
        )
        response = json.loads(response.text)
        token = response["token"]
        return f"{I_FRAME_URL}{IFRAME_ID}?payment_token={token}"
