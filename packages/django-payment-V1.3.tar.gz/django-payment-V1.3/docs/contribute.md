# Contribute

## [Add New Providers](./how-to-add-provider.md)

## create new build

1. change version in setup.cfg
2. call make build in your terminal
3. create a new tag in your current commit
4. make a new relase in gitlab
