from bit68_notifications.conf import EXPO_NOTIFICATION, FIREBASE_NOTIFICATION

MIDDLEWARE_CLASSES = (
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
)

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": "payment-bit68-tests.db",
    }
}

INSTALLED_APPS = (
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "bit68_notifications",
)

ROOT_URLCONF = ""

SECRET_KEY = "any-key"

CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
        "LOCATION": "127.0.0.1:11211",
    },
}

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "APP_DIRS": True,
    },
]


# package settings
# PUSH_NOTIFICATION_USER_MODEL
# PUSH_NOTIFICATION_UNIQUE_REG_ID = False
PUSH_NOTIFICATION_DEVICE_TYPES = [FIREBASE_NOTIFICATION, EXPO_NOTIFICATION]
PUSH_NOTIFICATION_FIREBASE_KEY = ""
# IS_TESTING_ENVIRONMENT = True
FIREBASE_PROFILES = {
    "default": {
        "PUSH_NOTIFICATION_FIREBASE_KEY": "123",
    }
}
