import json

import requests
from decouple import config

AUTH_URL = "https://accept.paymob.com/api/auth/tokens"
ORDER_URL = "https://accept.paymob.com/api/ecommerce/orders"
I_FRAME_CREATOR_URL = "https://accept.paymob.com/api/acceptance/payment_keys"
I_FRAME_URL = "https://accept.paymob.com/api/acceptance/iframes/"
MOBILE_WALLET_URL = " https://accept.paymob.com/api/acceptance/payments/pay"
Accept_API_KEY = config("Accept_API_KEY")
INTEGRATION_ID = config("INTEGRATION_ID")
IFRAME_ID = config("IFRAME_ID")


class AcceptPaymentHandler:
    def __init__(self, payment: object) -> None:
        self.payment = payment
        self.auth_token = self.get_auth_token()
        self.order_id = self.create_order()
        self.i_frame = self.get_iframe()

    def get_auth_token(self):
        response = requests.request(
            "POST",
            AUTH_URL,
            headers={"Content-Type": "application/json"},
            data=json.dumps({"api_key": Accept_API_KEY}),
        )
        response = json.loads(response.text)
        return response["token"]

    def create_order(self):
        payload = json.dumps(
            {
                "auth_token": self.auth_token,
                "delivery_needed": False,
                "amount_cents": self.price,
                "currency": "EGP",
                "items": [],
            }
        )

        response = requests.request(
            "POST",
            ORDER_URL,
            headers={"Content-Type": "application/json"},
            data=payload,
        )
        response = json.loads(response.text)
        return response["id"]

    def get_payment_token(self):
        payload = json.dumps(
            {
                "auth_token": self.auth_token,
                "amount_cents": self.payment.total * 100,
                "expiration": 3600,
                "order_id": self.order_id,
                "billing_data": {
                    "apartment": "803",
                    "email": "claudette09@exa.com",
                    "floor": "42",
                    "first_name": "Clifford",
                    "street": "Ethan Land",
                    "building": "8028",
                    "phone_number": "+86(8)9135210487",
                    "shipping_method": "PKG",
                    "postal_code": "01898",
                    "city": "Jaskolskiburgh",
                    "country": "CR",
                    "last_name": "Nicolas",
                    "state": "Utah",
                },
                "currency": self.payment.currency,
                "integration_id": INTEGRATION_ID,
            }
        )
        headers = {"Content-Type": "application/json"}
        response = requests.request(
            "POST", I_FRAME_CREATOR_URL, headers=headers, data=payload
        )
        response = json.loads(response.text)
        return response["token"]


class AcceptCreditCardPaymentHandler(AcceptPaymentHandler):
    def get_iframe(self):
        return f"{I_FRAME_URL}{IFRAME_ID}?payment_token={self.get_payment_token()}"


class AcceptMobileWalletPaymentHandler(AcceptPaymentHandler):
    def get_iframe(self):
        payload = json.dumps(
            {
                "source": {
                    "identifier": self.payment.wallet_mobile_number,
                    "subtype": "WALLET",
                },
                "payment_token": self.get_payment_token(),
            }
        )

        response = requests.request(
            "POST",
            MOBILE_WALLET_URL,
            headers={"Content-Type": "application/json"},
            data=payload,
        )
        response = json.loads(response.text)
        return response["redirect_url"]
