import pytest

pytestmark = pytest.mark.django_db
lazy_fixture = pytest.lazy_fixture


class TestFirebaseHandler:
    pass
