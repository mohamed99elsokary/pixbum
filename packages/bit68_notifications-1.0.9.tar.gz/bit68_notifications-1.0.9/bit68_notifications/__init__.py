"""Top-level package for bit68_notifications."""

__author__ = """Mohamed Taweela"""
__email__ = "mohamed.taweela@bit68.com"
__version__ = "1.0.9"
