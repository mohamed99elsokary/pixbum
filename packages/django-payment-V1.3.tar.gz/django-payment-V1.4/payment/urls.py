from django.urls import path

from . import views

urlpatterns = [
    path(
        "accept-callback/",
        views.AcceptView.as_view(),
        name="accept-callback",
    ),
    path(
        "opay-callback/",
        views.OPayView.as_view(),
        name="opay-callback",
    ),
    path(
        "success/",
        views.payment_success,
        name="payment_success",
    ),
    path(
        "failed/",
        views.payment_failed,
        name="payment_failed",
    ),
]
