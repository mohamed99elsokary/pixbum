from django_lifecycle import BEFORE_CREATE, LifecycleModelMixin, hook
from payment.models import Payment


class OrderMixin(LifecycleModelMixin):
    @hook(BEFORE_CREATE)
    def create_payment(self):
        # choose the payment type depends on which payment gateway that u need to use
        self.payment = Payment.objects.create(
            payment_type="ACCEPT_CREDIT_CARD", currency="EGP", total=self.total_price
        )
        self.payment_url = self.payment.payment_url
