from django.db import models
from django.utils.translation import gettext_lazy as _

from .conf import EXPO_NOTIFICATION, FIREBASE_NOTIFICATION
from .settings import notification_settings as SETTINGS

# bulk type choices

BULK_NOTIFICATION_CHOICES = [
    (EXPO_NOTIFICATION, EXPO_NOTIFICATION),
    (FIREBASE_NOTIFICATION, FIREBASE_NOTIFICATION),
]


class Device(models.Model):
    name = models.CharField(
        max_length=255, verbose_name=_("Name"), blank=True, null=True
    )
    active = models.BooleanField(
        verbose_name=_("Is active"),
        default=True,
        help_text=_("Inactive devices will not be sent notifications"),
    )
    user = models.ForeignKey(
        SETTINGS.PUSH_NOTIFICATION_USER_MODEL,
        blank=True,
        null=True,
        on_delete=models.CASCADE,
    )
    date_created = models.DateTimeField(
        verbose_name=_("Creation date"), auto_now_add=True, null=True
    )

    class Meta:
        abstract = True

    def __str__(self):
        return self.name or "{} for {}".format(
            self.__class__.__name__, self.user or "unknown user"
        )


# Expo device


class ExpoDeviceManager(models.Manager):
    def get_queryset(self):
        return ExpoDeviceQuerySet(self.model)


class ExpoDeviceQuerySet(models.query.QuerySet):
    def send_message(self, title, body, **kwargs):
        if self.exists():
            from .expo import ExpoSendHandler

            data = kwargs.pop("extra", {})
            reg_ids = list(
                self.filter(active=True).values_list("registration_id", flat=True)
            )
            handler = ExpoSendHandler()
            if reg_ids:
                handler.send_message(reg_ids, title, body, data, **kwargs)
            return handler


class ExpoDevice(Device):
    device_id = models.TextField(_("Device ID"), blank=True, null=True, db_index=True)
    registration_id = models.TextField(
        verbose_name=_("Registration ID"),
        unique=SETTINGS.PUSH_NOTIFICATION_UNIQUE_REG_ID,
    )

    # managers
    objects = ExpoDeviceManager()

    def send_message(self, title, body, **kwargs):
        from .expo import ExpoSendHandler

        data = kwargs.pop("extra", {})
        handler = ExpoSendHandler()
        handler.send_message([self.registration_id], title, body, data, **kwargs)
        return handler


# Firebase device


class FirebaseManager(models.Manager):
    def get_queryset(self):
        return FirebaseQuerySet(self.model)


class FirebaseQuerySet(models.query.QuerySet):
    def send_message(self, title, body, app_name="default", **kwargs):
        if self.exists():
            from .firebase import FirebaseHandler

            data = kwargs.pop("extra", {})
            reg_ids = list(
                self.filter(active=True, app_name=app_name).values_list(
                    "registration_id", flat=True
                )
            )

            handler = FirebaseHandler(app_name=app_name)
            if reg_ids:
                handler.send_message_to_many(reg_ids, title, body, data, **kwargs)
            return handler


class FirebaseDevice(Device):
    device_id = models.TextField(_("Device ID"), blank=True, null=True, db_index=True)
    registration_id = models.TextField(
        verbose_name=_("Registration ID"),
        unique=SETTINGS.PUSH_NOTIFICATION_UNIQUE_REG_ID,
    )
    app_name = models.CharField(_("App name"), max_length=250, default="default")

    # managers
    objects = FirebaseManager()

    def send_message(self, title, body, **kwargs):
        from .firebase import FirebaseHandler

        data = kwargs.pop("extra", {})
        handler = FirebaseHandler(app_name=self.app_name)
        handler.send_message(
            token=self.registration_id, title=title, body=body, extra=data, **kwargs
        )
        return handler


# Bulk notification from admin


class BulkNotification(models.Model):
    title = models.CharField(_("Title"), max_length=250)
    body = models.TextField(_("Body"), blank=True, null=True)

    date_created = models.DateTimeField(
        verbose_name=_("Creation date"), auto_now_add=True, null=True
    )
    # type
    EXPO_NOTIFICATION = EXPO_NOTIFICATION
    FIREBASE_NOTIFICATION = FIREBASE_NOTIFICATION
    type = models.CharField(
        _("Type"),
        max_length=50,
        choices=BULK_NOTIFICATION_CHOICES,
    )

    # firebase app name
    firebase_app_name = models.CharField(
        _("Firebase app name"), max_length=250, blank=True, null=True
    )

    # status
    is_successful = models.BooleanField(_("Is successful"), blank=True, null=True)
    response_log = models.TextField(_("Response Log"), blank=True, null=True)
    failed_tokens = models.TextField(_("Failed Tokens"), blank=True, null=True)

    def __str__(self):
        return self.date_created.strftime("%m/%d/%Y, %H:%M:%S")

    def save(self, *args, **kwargs):
        if not self.pk:
            self.send()
        save_return = super().save(*args, **kwargs)
        return save_return

    def send(self):
        if self.type == EXPO_NOTIFICATION:
            self.send_expo()
        if self.type == FIREBASE_NOTIFICATION:
            self.send_firebase()

    def send_expo(self):
        handler = ExpoDevice.objects.all().send_message(self.title, self.body)

        if not handler:
            return

        self.response_log = handler.log
        self.is_successful = not handler.is_failed_request
        string = "\n" + "*" * 50 + "\n"
        self.failed_tokens = string.join(handler.failed_tokens)

    def send_firebase(self):
        handler = FirebaseDevice.objects.all().send_message(
            self.title, self.body, app_name=self.firebase_app_name
        )

        if not handler:
            return

        self.response_log = handler.log
