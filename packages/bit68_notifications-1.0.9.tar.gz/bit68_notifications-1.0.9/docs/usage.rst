=====
Usage
=====

To use bit68_notifications in a project, add ``bit68_notifications`` to the ``INSTALLED_APPS`` in your django settings and migrate.


Push notificatoins devices
-----------------------------

Devices are models for the different push notification provider. You can use Device model directly to send push notification.

for now there is only one device to use which is the `Expo device`.

Expo Device Usage
-----------------

add an Expo token for user::

    from bit68_notifications.models import ExpoDevice

    username = "Ahmed"
    email = f"{username}@example.com"
    expo_token = "Expo_Token"

    user = User.objects.create_user(username, email=email, password=username)
    device, is_new = ExpoDevice.objects.get_or_create(
        user=user,
        registration_id=expo_token,
    )

now you can use the created device to send a notification::
    
    r = device.send_message(title="welcome", body="welcome again in our app.")
    print(r)


Bulk notification
-----------------

This functionality is available by creating an instance from the model ``BulkNotification`` and providing the notification type::


    from bit68_notifications.models import BulkNotification

    BulkNotification.objects.create(
        title="welcome",
        body="welcome again in our app.",
        type=BulkNotification.EXPO_NOTIFICATION,
    )
