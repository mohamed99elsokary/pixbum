# Contribute

## [Add New Providers](./how-to-add-provider.md)


## Try the Package in project

At first, you will need to add the package directory to your python path.

open terminal in the project directory, and run:

```bash
export PYTHONPATH="..:$PYTHONPATH"
```

then you could enter the example path, run the migrations, create super user and run the server.

```bash
python3 -m venv env
. env/bin/activate
cd test_project
pip install -r requirements.txt
# install pre-commit hook for formatting, linting and checking code 
# use black, isort, flake8
pre-commit install
cp .env.example .env
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver

# try create order using accept endpoint
curl --location --request POST 'http://localhost:8000/api/try-accept-orders/'
```

then you could try the package.

## Build and create new release

1. change version in setup.cfg
2. call make build in your terminal
3. create a new tag in your current commit
4. make a new release in gitlab
