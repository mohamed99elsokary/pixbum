# Notification types
EXPO_NOTIFICATION = "expo"
FIREBASE_NOTIFICATION = "firebase"
