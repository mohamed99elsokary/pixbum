from django.conf import settings
from django_lifecycle import AFTER_UPDATE, BEFORE_CREATE, LifecycleModelMixin, hook

from .utils import payment_providers


class PaymentMixin(LifecycleModelMixin):
    def get_payment_provider(self):
        return payment_providers[self.payment_type](payment=self)

    @hook(BEFORE_CREATE)
    def after_create(self):
        payment_data = self.get_payment_provider()
        self.payment_url = payment_data.i_frame
        self.provider_order_id = payment_data.order_id
        self.provider_token = payment_data.token

    @hook(AFTER_UPDATE, when="paid", is_now=True)
    def after_payment(self):
        if settings.AFTER_PAYMENT_SUCCESS:
            settings.AFTER_PAYMENT_SUCCESS(self)
