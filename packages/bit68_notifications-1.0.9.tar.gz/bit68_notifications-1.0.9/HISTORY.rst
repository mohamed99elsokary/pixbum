=======
History
=======

0.1.0 (2021-07-12)
------------------

* First release on PyPI.
