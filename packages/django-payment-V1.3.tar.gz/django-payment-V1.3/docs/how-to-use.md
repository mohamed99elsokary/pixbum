# How To Use

1. add one to one relationship between your order model and the package Payment Model like this example

   ```python
   from payment.models import Payment
   from .model_mixins import OrderDetailsMixin, OrderMixin
   from .models import User

   class Order(OrderMixin,models.Model):
     user = models.ForeignKey(User, on_delete=models.CASCADE)
     payment = models.OneToOneField(
         Payment,
         on_delete=models.CASCADE,
         null=True,
         blank=True,
         default=None,
     )
     payment_url = models.CharField(max_length=2000,null=True, blank=True, default=None)
     total_price = models.IntegerField(default=0)
   ```

2. create a Payment object using before create hook on oder model

   ```python
   from payment.models import Payment
   from django_lifecycle import (LifecycleModelMixin,hook,BEFORE_CREATE)

   class OrderMixin(LifecycleModelMixin):
     @hook(BEFORE_CREATE)
     def create_payment(self):
         #choose the payment type depends on which payment gateway that u need to use
         self.payment = Payment.objects.create(payment_type="ACCEPT_CREDIT_CARD",currency="EGP",total=self.total_price)
         self.payment_url = self.payment.payment_url
   ```

   if you want to use accept wallet , you have to provide the mobile number when creating the payment

   ```python
     self.payment = Payment.objects.create(payment_type="ACCEPT_MOBILE_WALLET",currency="EGP",total=self.total_price,wallet_mobile_number="+201124250328")
   ```

3. to handel after payment state you will need to make a function that takes the payment object

   > for example i will make the function in services helpers.py

   ```python
   def after_payment_success(payment):
     ...
   ```

4. define a variable in your settings under that tells where is the after payment location this var have to be in this name AFTER_PAYMENT_SUCCESS

   > don't add () it's only locates the function location

   ```python
   from Project_name.services.helpers import after_payment_success
   AFTER_PAYMENT_SUCCESS = after_payment_success
   ```

## [contribute](./contribute.md)
